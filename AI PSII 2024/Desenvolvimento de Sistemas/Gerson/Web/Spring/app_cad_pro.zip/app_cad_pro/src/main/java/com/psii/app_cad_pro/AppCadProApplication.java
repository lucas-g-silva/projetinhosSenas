package com.psii.app_cad_pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppCadProApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppCadProApplication.class, args);
	}

}
