package com.psii.app_cad_pro_ped;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppCadProPedApplicationTests {

	@Test
	void contextLoads() {
	}

}
