package com.psii.app_cad_pro_ped;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppCadProPedApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppCadProPedApplication.class, args);
	}

}
