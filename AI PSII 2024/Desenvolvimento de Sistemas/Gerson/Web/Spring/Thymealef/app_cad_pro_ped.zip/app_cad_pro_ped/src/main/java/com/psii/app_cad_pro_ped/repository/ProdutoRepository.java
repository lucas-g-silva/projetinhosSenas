package com.psii.app_cad_pro_ped.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.psii.app_cad_pro_ped.model.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

}
